@extends('layout')
@section('title', 'Home page')
@section('content')
    <h1>Hello Laravel</h1>
@endsection
