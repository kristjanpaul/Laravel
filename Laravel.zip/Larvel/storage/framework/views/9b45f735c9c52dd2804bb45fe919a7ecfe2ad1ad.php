<?php $__env->startSection('title', 'Articles'); ?>
<?php $__env->startSection('content'); ?>
    <a class="btn btn-primary" href="<?php echo e(route('articles.create')); ?>">New Article</a>
    <div><?php echo e($articles->links()); ?></div>
        <table class="table table-striped">
            <thead>
                <th>Id</th>
                <th>Title</th>
                <th>Created</th>
                <th>Modified</th>
                <th>Actions</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($article->id); ?></td>
                        <td><?php echo e($article->title); ?></td>
                        <td><?php echo e($article->created_at); ?></td>
                        <td><?php echo e($article->updated_at); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('articles.destroy', ['article' => $article->id])); ?>">
                                <a class="btn btn-primary">view</a>
                                <a class="btn btn-warning" href="<?php echo e(route('articles.edit', ['article' => $article->id])); ?>">edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger" type="submit" value="delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <div><?php echo e($articles->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andre\Documents\KoroonaKaust\Suurusalu\MM-19\Lärvel\Larnavalelalel\resources\views/articles/index.blade.php ENDPATH**/ ?>