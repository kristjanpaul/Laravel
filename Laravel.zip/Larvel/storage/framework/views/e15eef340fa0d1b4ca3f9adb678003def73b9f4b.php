<?php $__env->startSection('title', 'Home page'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Hello Laravel</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andre\Documents\KoroonaKaust\Suurusalu\MM-19\Lärvel\Lärvel\resources\views/index.blade.php ENDPATH**/ ?>