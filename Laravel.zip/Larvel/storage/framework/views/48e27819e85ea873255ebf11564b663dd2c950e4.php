<div id="slider-<?php echo e($id); ?>" class="carousel slide" data-bs-interval="false">
    <div class="carousel-inner">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($key==0 ? 'active' : ''); ?>">
                <img src="<?php echo e($image->path); ?>" class="d-block w-100" alt="...">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#slider-<?php echo e($id); ?>" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#slider-<?php echo e($id); ?>" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php /**PATH C:\Users\andre\Documents\KoroonaKaust\Suurusalu\MM-19\Lärvel\Larnavalelalel\resources\views/partials/carousel.blade.php ENDPATH**/ ?>